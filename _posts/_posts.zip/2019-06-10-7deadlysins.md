---
layout: post
title: 게임불감증 완치! 10년만에 겜창 리젠되셨다. 리얼갓겜 일곱개의 대죄 리뷰.
date: 2019-06-10 20:30:00 +09:00
author: 2tmdwo
permalink: /real-god-game-the-seven-deadly-sins
image:
  feature: thumbnail2.jpg
categories:
- 모바일게임
- 칠대죄
- 일곱개의대죄
- 게임
- 리뷰
tags:
- 칠대죄
- 칠대죄모바일
- 일곱개의대죄게임
- 칠대죄게임
- 폰게임추천
description: 뜻밖의 덕통사고로 1주일을 잃어버렸습니다. 10년 묵은 게임불감증 완치에 직빵

---

 안녕하세요 여러분. 승재로드의 틈두입니다. 오늘은 게임리뷰입니다. 요즘 먹는거보다 더 빠진거라서요..



![gamemain](https://lh3.googleusercontent.com/2l1WDzaU7zcv4RVP0exV_Kt_fX1x4Fe4i9wOyKDiVzo2eM500iNErXf-uG_B7LDv9KcgCUoWZM_Ct35Mqf1TtHFBSHBfuQ3ECVfBX3gT2HxkZX8Tnf7mhTI1HTngZQGe89j4M7J0uRHaEMuAWN8FfJxplmhFAvBR1VX1dS1BgstkRuY02F1dy4N7gC-pxL5M8gpJyE5hOWr6OxTMiXuTcvfY-_n-YfRWZxd-5UeQnqxX73bu8Yd2m-sWeFoKtXO9xr8q9wH6GqwFmGXMRqHuqw5djtfeiSRs5o_O5v_KuMW2x-aVLWo7QVcGsm3U8V3RBSvmNyE6cJkIVFf9DgTfwMTjJ9YP8PTqqGzI5EbPCaO_ylqKLlsb2CcBetVrWm7ZeQx7uRMe2IqpYzAVqCXEuKuGKgg5rW1kvhIxVAZtpQLE_Km9TiBdt-SlSmYe1fF087Ha7NyUCn8wals_plIbWZ3pboVCf3UvuhZ4zk_ULyGvSMSEhMIcWa7oC3XdT0M___jb6sn7XK44RJ4rUl-8K12VlvtFWF5rol6-1iXQV5R0x9xjDarZBWMpony2WLiLoTycTN5z6TqTFjfh3n6Roj1-D8Bgaanyy-kTgnyCVHNgTHDb_KGoO_VBz4A-hfsRy_oyiTvvZ9wYmBdFHo1ubLAP49FmdPwQBUMS1aZW5Fp5bLOrdoKwhxRsy10LIdr69LliVdSLMa-1-x_6tl145zz_=w432-h768-no)

 

서론

필자는 어려서부터 동네의 유명한 겜돌이였다. 나를 키운건 8할이 패미컴이요 2할은 오락실이렸다. 일요일 아침은 자유 게임시간이 주어졌기 때문에 새벽6시에 일어나서 2시간 40분을 내리 패미컴으로 게임을 즐기다가 8시45분에는 디즈니동산을 보는 것이 당시 내 삶의 낙이었다. 그 후로도 

오락실을 전전하며 삼국지, 킹오파, 메탈슬러그, 씨가 축가, 철권 등을 거쳤고

컴퓨터로는 포켓몬과 디아블로2, 레인보우식스, 

플스로는 매그넘 형제가 나오던 미니카 게임, 레이맨, 위닝 등으로 내공을 다졌다.

플스2를 기점으로 겜창 인생은 대 전성기를 맞이해 마계전기 디스가이아2를 인생 게임으로 영접.

그 후로는 다양한 대작들(디아3, 리니지2 등)도 나의 맘을 흔들어 놓지 못했다.

![whymyheartsoshackshack](https://lh3.googleusercontent.com/HKXkK_kqsI5yxxd6oBdAZPNQ63Qd21CuODcazVmbnXl_0YbnbjJI-U9QzHD92KN8Jun_Lgi_wA54ZqFYHilRCFsf70xrW2PzSp5Rg7nPJcHCecfp8XqY7AU9cS0kPUm1cEIROddXhUCpZI4s1WPAh0qX1GMIijZ7iaB5HTGO9Ac9yMogR3Ioc-A-9aNAqDzrx4sqH7kRNe8sfbj_6FC7wa6GHHUgk4RPjfYwoSxNzwY6ESc8KgC8_dcpfCNL5BfjHGCrOHbfXQ0LFpaIafKcw4N3VakP8tWuFm6IpD39anMSE4geuIsLpTLfgGaPbvmN1ilf-7ayYJFqY_bn5D3XWimMj5-EyUyzJfHuDyDHxTvsbBq0wGcEQSd0ico160chwP_PDFO5Udlo94s_y4FYr3FvH7RC2WqZBLUGQ4XL867A7JqGz00IO7G3zOuJsdqpAHcHpzl8qrBqoEVRMTacABmOoHYOzE3XISMKAQHU4qN0v3zphIVSyrzTFNYxJLxrVXA4gJT3UtOAfUzMWNwFjuOWvaWqVvCcNd36GcToc9KLA2PXYZanj_tr-n8tnnG2mBmqTWsBihYlnWUkNYiVbOe43iDGKpQkTUUxtN3dcg2ECyrIZolvbM-vOyoHAuX1UFN8RZXTnIfuRA7IKOv00n7dgfOD12wB_940EjWCGnfsiZ999JCttbrVKRzEY2KFYG2YFkY4WkJVuib6bpZQinco=w953-h537-no)

그렇게 겜창 인생은 마무리 됐다고 섣불리 단정지었었다.

그러다가 스터디원의 마케팅 전환율을 높이는데 일조하기 위한 마음으로 받은 게임 ‘일곱개의 대죄’

그리고 나는 내 일주일을 잃어버렸다.

지금부터 그 썰을 풀어보도록 하자

![img](file:///C:/Users/lsjbl/AppData/Local/Temp/msohtmlclip1/01/clip_image005.png)

![appmarket1st](https://lh3.googleusercontent.com/3YchipPdd6-KPv80LzgNqooqqWwIAMpjeAx_Pseccesva7e9rSbl9jSWorhUk_Ez35xbEtCkVkAcUp_w2NXOq2wY156kzPwXIMWN34CN1h-9OeEZWjXsuvgce3j1anoWJyEWI3fI26xmpKXzPfUD-7nJ_WPtSfncomeyZuUOaMFF8GDfofSGYCDcej7ZGHl3Omvb0cO1hf35MKgD5OZZmotEkX3vVdz0UE4F0Lqbkrq8_GpOzSbqyJ3y2i149MXwvmke1ndKSQk3gRc4n7WDBD0p8NMxfkHUBe4Qle4Qt7EBeecCGyQ_4c8ePPWkHrIVxf6Fk82wmG4_Xe3bFxkIJb1UQzd9cWe1cdjMFoll0jRpTvyoYs5OB7raPfhggSfxFtKTMzQrTuI5iphVtLemrU7aLC1APDhyCxPTYtx1xXGGsY426YhpZxpv5F1ChNt7Ycm5cVzT2Bff-EVybs1eQ5pTUj-TnVhPrgFwfYcYtDFnW65e_sbHdEuQYE-_SScl0Yx4jr2LltIaDnl85QyNPTO7gxhyRYtPjXPLGrQR9klQsdSZ71HiQ-p6Y3A_GnCdEI7h4aN3obGf0nTF4af3jCaBqTZW_gQM66FgU1BSa7h2fhAtPjls88L3wiw2wVj3-0eXYi93p7CIrgjdRYS7ZzAP8eOCYwrB1rzWq1HHIAtgpTyP-RfPh4lU-yVFj5hpP2hBOD0uu5bIvW6hsyEbEdTk=w953-h715-no)

일단 굳이 내가 막 예찬을 하지않아도

이미 게임 카테고리 내 1위를 차지하고 계시다

물론 돈 주고 건 메인이겠지만서도말이지

 

그리고 출시 1주일이 채 지나지 않았지만 

![bestsellingappongoogleplaystore](https://lh3.googleusercontent.com/BkM-ahRmmhgiR8IuFk-rrTcZktBuIRrC2Vf0QpSOJvWXWHFzOG4xb2KlslYOKbUIMDOyKVhdQy8R4aFPcKOmdcjZBfJPjs0mqjbshaxrYZ7Lr34DZdsmih9gJ_cnkW-aI684Zburm5OxYzExb-mPNKbqcZRYLW8Cw7w1HyRjx3O8_SCTXRSbbTnvrQJPjbrjHWZbV02VA3bzF7iEWTxY7arOT1KCbLI1zITxec7We6H1u7kMl4PExGwOa1hj5Mqrv1WpCVu3QWtRFQu7XwxBbKJdBrutOA72l5GqgsusNNxM0DhoEvxanFoVsZhVYhJRu34ljnTc06YgkNfQ3Octq_0U-udDEL6RKpyMjcJFNUIeEhG9xjSmlMbNogGaUBFWOn8EOiBN9DOtqGCTJc8ttRuPpLWpb-150DRU4NDgDkUp3hw0x-jJkpHmwNLKWWCYNKoxDtTia5BBIiOI4JMf37t0nBPCQuz9qEXlKTyLwvfbWphOBGhdLVkXnNe-amIqTl4Htk4NeghXEtcSk9xKCy-q2ZdE9LH15gSBHAi2ItkbU6cYJ0Zjj2yLcbO-mR4CmcKageHi-76AVUx04Ynh6I4BRvr0a7IfKoXqVHa8NGUzsyUhPwSNKWlxXVN83QblDC832znBo6NMvnQZIWoaseMLBUxy8EJIoaFvK8_4UnZ19_dEa3GsjZIcT5XPDMDj09v1ZTdLUSdOmPfYvutvjTDM=w953-h475-no)

이런 기염을 토하고 있다. 넷마블 관련 직원들 PS올라가는 소리가 여기까지 들린다 들려

 

아무튼 굳이 내가 빨지 않아도 이미 엄청난 인기를 구가하고 있다는 것 증명하기위해 굳이 혓바닥을 늘려봤다.

 

일곱개의 대죄(이하 ‘칠대죄)의 대단한 점을 게임성 및 컨텐츠, 과금유도성, 원작 구현도, 플레이, 운영의 5가지 측면에서 아주 아주 개인적인 리뷰를 해보겠다(필자는 지난 10년간 게임 불감증으로 접해보지 못한 게임도 꽤나 많다. 특히 스위치의 경우 구입한지 1년반이 지났지만 총 구동시간이 25분밖에 되지 않는다. 갓겜이라 칭송받는 젤다도 마딧세이도 필자의 맘을 흔들지 못했다.)

![myfirstur](https://lh3.googleusercontent.com/_KIqqOmTUFFiCzw7tNS4ZCU1sq4h7GnITQB8cl41XeE4hhG4xQODBP1IjKn4CVbxlCNzsEgRESYX8Up4f8F7xtj5VBTwyYHfZxM9B0GbQip52a-OIbbq7vNGlCwZlx9ZEu7It1jB4Fojbn4Pob_rCHWYL2RmNYf33vmc76EgB-TrpG4bSWJn7lFVSJGUrOMYNKVfZ6lD36DQl-w4MpsYsSbX1xD3LJ_1MiAYVhAUNVA578GpsVlqSGa8VDEQeNEO102Pp3670Vp_m_8G5i-iThdYCTc6vQhKoZZwOAJDpsqiM2moAHEHkfoEPy-MExtS-OB1OSKIonmroFuVd8zRxhPXSLKF9NOxvltGWPTnTUVSDN0_e5__fMRXo03hrbfQFkvpNfj0eZYN29pEE86oUof54MYYNtVPsu0PW799QSAfkavHVqkqOts9HApJ2yrh7akWsbdVJD4m6aU8UR9xG1cxHbduA9YnOZd-_hUT67KOHKgXMyJrb8GbHc7GYovtBxNKg28olbNSH4Y_j7TsKiSMoF-PX9BnG5eoTbYPjU2eiK0woj05Z1jAXorDDtKcF0_pZ_KaKFFPaQXedMq4HHzf6xxqDeH5oT2Ggs-04ZB95Zt5jk_Azz8ne5QyCGz0S1KDvLFTFuQRZHLUe-UdYUEXLc-YdDqZWT9zjL8ewe3xO2zEfv7XJb0yKEV_pa3DRyKGSHx9ZvoKxWd4MUZmbdfk=w413-h870-no)

**게임성 및 컨텐츠(10/10)**

이런 제길 글을 쓰는 도중 섬멸전 도움 요청이 들어왔다… 도움! 도움! 도움의 손길을 뿌리친다는 건 진정한 겜창이 아니겠지.. 일단 하고 온다! 조지고 온다! 마신족놈!

 

조지고 왔다. 벌써 16분 가량의 시간이 흘렀다..

후 아무튼 게임성은 이렇게 글을 쓰기로 맘을 다 잡고도 게임을 하러 가게 만들만큼 마성의 흡입력을 갖고 있다.

 

요즘 모바일 게임의 필수요소는 다 가지고 있다.

행동력(게임을 플레이 할 수 있는 코인 같은 개념의 것)

다이아몬드(현질을 유도하는 게임 내 화폐)

자동전투(자동 전투가 적당한 수준이다. 인공지능이 있으면서도 약간 빠가인 수준. 굳이 예를 들면 보스에게 나가야 할 필살기가 옆에 잡몹에게 나가는 격)

진화 및 아이템 강화

이러한 게임 속 재미요소들은 자칫 잘못하면 굉장히 피곤하게 다가온다.

게임의 기획이란 것이 그래서 굉장히 힘든거다. 적당히 플레이어의 자유도를 존중하면서도 기획자가 짜 놓은 내러티브 속으로 빨아들이기가 쉽지가 않은데 이 게임은 그걸 너무 잘해놨다

![donewithhendel](https://lh3.googleusercontent.com/K6UUQ7zwxqIiuZbYomBBxulTCSISTT2YQvCFwPKzVDzrjoKbk7_bNrhfKrtFKl-cnZwc2Qca2Lfx1d6CX2QHpol57zgTHHPkgj8C6jCHCSo9EUQrKD2fvu2qfEaYziFYtllBw9D8Vx2dfny5Kxfg5Nx3-Kfr1gK0smZk1URh5WhXJOLyU6ypE8TI4qhNS7qNot9-hcWGSXDnBSTCbwAtqd5J_6xIilN29CgXWPffb3TbMZ_oTpYm4fWtmGyOmqr5AbuznoPlK_nAMLNOhXiOsWCM3Gi7_SvPnX3cgzczG8hcsBzxXen6VlJwDlweLRBfnrabQ0ULBoekPmQsQzd_870RiDtB624pjxUEg3T3DHn6DzY9VkVNbET-tBVvE3rZsl1jqqg8pcBtlsB_1nMQii1fwHnxL8zX1m87VupEf8ee8PTg0JRos-AaIiCEJxZxZt1luG3RYH9C7xysZ_8Aek1OH3GNGsF2auX84zNzAvfe3Dl7YjHPqpBhKvLE_qfvWYsSX7br08-JpfAEy063i_fD2HqtQvmurZ-h1ecnBu09NoiSay-F6avOq3ghdf1OdXKqBTp_T5ibhTfSm5YtGcQBYzzzYGd8NLQYipCr9najad3V1Obt-F3XNXrCZK7v9AFBHxA2mcRt0u1D7Kz3GxBvkOyUByteOoPfbMGr940GjXZ2mgpRFbB6p4M__tEEc2EpVzNIiv3ZOGE-TpAFhG-2=w426-h240-no)

헨젤과 그레텔의 마녀가 환생했다면 이 게임의 제작자일까 싶을 만큼

엄청난 중독성을 자랑한다

행동력이 차오르는걸 차마 눈뜨고 볼 수가 없고, 포션을 빨고 있는 나를 마주하게 될 것.

![characterupgrade](https://lh3.googleusercontent.com/Kd4f5czzykuyjcQd6sucSxmGQB6GJHYyXW0rf1gWPHu8Ba7k0nlJpmmnqcLRCgdbNcsWpZ1yMvXu53UfL49D1PJtLZb-rK2Lp8MruDqVOj6t7DxGOljW63q0zrCD2TWoMboB5Zj0fdOV4vWtvLQxj2sYismIq3a9wuRu-digcaxzpvu7V4mJx3MdzEBe1sZcr-NiUofWIoKjqYynZ182LSM7cZeRuhd-KXFlbjaiohtTlnJhNzccebEvpxVyOBN6LheUr9n9NS6PO6YWd3w88ajRXdHS6TggNWQF7eUBC57qTpQTZe8nP9J-cbSTBE2iIXJMJuO2Lq4kuwFA_48Y3E0izn4wGA9sQlMK0osa85hZcEHsHqrsC5zKH8pGTaDAFKDXt0Vxi0U0lvGK0hS1tyhnEVPtK9bi4Gdg8qvXumwC6IaA01iPGKWWfDgAjm3EdNTN65ubV2tBrXPnXshsY7fVrhmvMp8H6ElbKCz_7Nmd_3aKDIxZUa1wGH17RBoVTaMnR9RPnzm_U_509GNQo5u1eZ08j_SlMCCtcnFzGXLNA_qabQA9ZUJsY8UjaDk2oI9iRs11ECV2neVzRMYD8hFx7CCkb_f_WjRh2ScdjBBg4PJS2xCVMkMre1S8YwxH08Uwo90SOEsAqPGnBb_zzgQTIBjX-HKcU8NTjHBRYI9u99OzoqLCvTF9nC9HGSuqlQw31V4dahHkGkTZs0eU7G-N=w413-h870-no)

**과금유도성(10/10)**

칠대죄 역시 돈은 벌어야하지 않겠나? 근데 과금 유도성이 과하지 않고 아주 딱 적절하다 스토리 모드를 진행하는 동안 딱히 과금이 필요하다는 생각이 안들 정도로 무료 다이아를 적절히 뿌려준다.

그걸로 충분히 가챠(캐릭터 뽑기)도하고 신기도 사고(유료 코스튬) 가끔 심심하면 장비도 뽑는다.

가챠를 좀 땡겨봐야 그 확률을 알고 사람들이 현질을 한다는 것을 아주 잘 아는 넷마블의 심리전문가 놈들.. 분하지만 칭찬한다. 

![gotcha](https://lh3.googleusercontent.com/yICELZAMqZFSx-TPuAdZvmcSDBayd3NE8flNbYEvnfZYHSZ8ApzwHILEkZVhCJtmPXehr0zmKQtIHomfGIRG3D-xRKxc6tZX8MBmsL0bd4fuuE9j5D3s1Vb6BoDB8II86kMQjGPMrwNAIW8U_c1IF-1XzvXURnRRgRFja7WE3TvPJr1X7OtLRyQDtT16CdY28Xdyw8oXpubRYiWXwY6Uw0m6SLmRfcqX2HmJ01CG3cToKbzlGhOfXsQtakU-AWBjJ4OJ_N-D33DO3fIDz1EVMC9LO8j55k5yG_jHkkUVKMKgb5wSR2rHMAo10YnvGPQU7h75-iWALhi4Nxd93alJwsCAscjv1jne4eUNB1BkO0I3__3kCRcQn0luaxH7cZbHDTom2NNNd9zN2Eo7cn7J1tzqaTXh2fVZsJrXQIQ9kZe3wIrreARmMD94BA6gYv-ic1tSvmwsSXfIdYd73_znYr5hZmD1iUDmK0tJG-cIFCO33nmN0EAvzIarHYG2hcvehfA20-1LXNAsFAvk-q5VZok6Qs2QM_ojm0akhiPy-UcbB2S9dFYoqrt51P4THLQngXYstRtOBWJIs_YylqxlnGKAyb5iOpWbHjLpESgydDcUJ-ptVUVkYgXjwa9JqDwWCIM22dXnkdG68X4H0vOHnXVOgrKICxcnrkGksHKVTctMglEaP-bL57sHApSn6T4ZGn5Dj05AO8zgor4mcjLwTePU=w413-h870-no)

**원작 구현도(10/10)**

원작 구현도 면에서 특히나 높은 점수를 주고 싶다. 칠대죄는 현재 애니메이션도 2기가 넘게 나왔지만 한국어 더빙 버전이 없는데 게임에서 더빙을 캐릭터 별로 했고 심지어 성기사단까지 어지간한 캐릭터는 다 들어가있다. 이거 정말 대단한 거다. 돈도 엄청 썼을거다.

물론 게임자체는 일본에서 만든걸 넷마블이 라이센싱하는 거지만 한글화 및 더빙 등은 돈을 엄청 썻을텐데 정말 거의 완벽하다고 칭할만큼 잘했다. 넷마블 이하 에이전시까지 칠대죄 팀 파이팅이다. 칭찬에 박한 내가 아주 아주 칭찬하고 있다. 게임도 잘 즐기고 있고.

![masin](https://lh3.googleusercontent.com/QhCgWpl0gCZayaK6WP-lHC5EmVD3rZkm4PdZcRPyxRh0sIRJ4dFDqsyplMJUmCITMImgtKiCF9fnpj6jV6aq6rHNyOecfzJDct5auOOYdKs6Sbx2WN6e9CZEL670atpCQC3CW5UBb0o35Y4V0v8BzaFaHkSJbKTlGl_Ydbb_m7WXlY4hZ0vI6tjeMrZDnQpQGRUC34NFZM_DiwDdwXlJy0pdqBPXW8TMbQ4I52V5vhROxYK_YNU5T8XavmzkgM0OiLDyPJL8KKy34_JlBwYciCA7u1p7yxQ3bQrrf9oQqipC-ODUvuPlMhpcke_lrVEDGzRldairwk9yYnCDgyE8PheLEzklfCAUBS4K93OO7eEj7OOuhZ6vPbllB5hpPZ-L05gECdswaKAWa54RYSra8ecRScEJS7R15dKeHq6bEVGaRyuZcTcQ_W0BFjIj4UPMd04l7_Mul03zVNBLk6cZjrn7jzo52Owt1umEaaALnbF8GCkxKOLqB3hzEJki2udYxxJWXq8xdAxKqPm0raVaBhk6OfFMS_dt4IOkbzYIcVouTovfLro-pv7O-Jvoa5lsCwvYVsE6uA7MgkkpWancGSbpwZpBw7ky9JGxOb1BJ9igaBBRVoAHmdIItXsn8cFmP9zKVXyPO-gTh9PdV3gY7N5ySvIFsDj5Nlz6_2DmI6XX1N0XTgdWU0aHsVnegvrpRMoet12oBZe4LwxK6eAkHYXx=w413-h870-no)

**플레이**

 

**운영**

전반적인 운영

 딱 지금 필자가 현재까지 나온 에피소드의 마지막 장에 머무는데 극악 난이도를 자랑해서 못 깨게 만들어놨다. 그래서 노가다 작(캐릭터 성장, 진화, 각성, 스킬 업그레이드, 개성 개방 등의 컨텐츠 등으로 노가다도 아주 다양하게 심어놨다)을 유도하고 그 사이에 컨텐츠를 풀어주시네. 

지금 글을 쓰는 와중에 1.6gb짜리 대규모 업데이트가 있었다. 아마도 멀린을 풀어내겠지?

적절한 컨텐츠 업데이트까지 완벽한 게임운영이다. 

또 초기 사전예약 이벤트와 리세마라 확률도 생각보다 나쁘지 않고 계정마다 가챠에 한번씩은 SSR 3개씩 터트려주는 낚시질까지 완벽한 듯하다.

![masin2](https://lh3.googleusercontent.com/CLiSsJ1LrwKz3zEpIBfKUjbRxesfXnKaly2M3xkyA5kkA8tUFMl-2Z_TmNmvySizgzE8VTv8WRH7iYqflXB-B-oIHDF0mpRhSsv2t9I3sF5d2NnPxYqhLi9PxeuMUjD7iKG3zurALBlHDg7mmAXFllIZmhpBTfXyqVXajGCvDKOS1VXcCt8uMuNEzjwv7Mv6W3TmXlng4WhK0pgKPtDg_coF_kobd_pxa-zzs81aFD-vyuyt8ATz3E6bjuS8kcuXmRTvCpZNfzx2oJCrPMPeAlms-Jcmq6XtUxlNVLq_1H0U4d7HdBr19KEBNtjufXdQB1DwNbQoryo4wMjPofvUnfX2Pj6wPn5gjFnOoy6S1fwxevgxZ17qTSNeOQ-XWugFswtVLCbukCN_6LUVKb7J_eeSyOKmHOGeg0A1BSA0uf59EfjLnhlc5quup-7cCxiSHDrx0xlvbiPJWdjOJ8dim2ufMoMI5y3HhkNNenqXnYAHA9k1aX4PhsC06Lo1mpOK0xWePlsmEeGOfRzzJUsN2uJ1bLp47d07nGq39YXbo-2bJOuS8gV9jkjxtV6Mg89uBK1lcnnDQDhv7M_Og-_i6iqEq2--J789WIdo_qvF3kpQQzBv1k24ar9WiDABPbEdl9BokmkcuGGzfePjKdppdNA0LMTNTS_0r4Xni1TviRyRU82dbOpZBozgE4TCqOueTd82Uu1MbkwZjyxwwkRmo7yr=w413-h870-no)

버그대응

또 초기 요리재료 이벤트가 반복적으로 수락이 되지 않는 점에 대해서도 발빠르게 대처했다는 평가가 지배적이다. 

 

이벤트

현재 인연인증, UR캐릭터 인증 행사도 어렵지 않은 난이도 내에서 응모가 가능하며 그 응모 방법 역시 굉장히 쉽다. 게임 접속하면 뜨는 커뮤니티 창에서 덧글로 자신의 캐릭터 화면 창을 캡쳐해서 덧글로 달면 이벤트 참여 끝이다. 조금 더 많은 이벤트(예를 들면 오프라인과 연계한 쿠폰 뿌리기) 등을 기획하고 진행한다면 더할 나위 없을 것 같다.

![yes](https://lh3.googleusercontent.com/W2-bPBdjObYs--5TY_11WFje5WKel4faFmblrlIsxF0rYVGYrpVxBlIOsIrqjkJdfiKVn0GYpNLtb4K0nX_uay-DRmV7ZHkHXGaypIgNFS5GNzp32FjjiSYB7RPTm8ZbKCj-k1QlqGmaJsIJWE3Jp77SwsqeaZtd9Q70HhNufd5xT8ZfNwLE8Y6ABc6wXaWEdmcmwouXTib31FsuN3apDhT0pnmSOyR8ZkYjZya7nGo463gd-gFKOsRaYPAI5W_5TdHGBD1GrWh2LC5vqrRVCEBMJOdD0LzaH1WQY_zrCZdiFA67AUX3iSvOhk8FG8mpWBSTlDgbZ25GzUx4hcl_oqH2GAoRQsWWE04V9MA738J7ydVdv1voHefBpIU185cVA3bLPsNwrXB6mksNnZy5lWMrks36uHLJOgUyJwZtnCIr9lUOGx1oJtbZnuGs79cEo_jC6NkQG4d1fvX4zFebGmB8nny-FENY-XO-iv1HpTeP96--FfEf2UUds7A-hL_pSVbxRI7FSLdDoaIRObgzALv7NZ9derd2qyBEmmeppu7hQNGcVkGntVO12wva03j45Fq7zmRCByqLWMBpByQihB-f98kpMuk-CAYDT0zkH6mw-9nAIt2urnTocfu_rJyTOfQEIh2pVPR3fNLkTQjqMyYRJiyNYMl1ZXXan0axwEeDeNAnFr1ULCf7ff0N-oCoNBeCCBJkLOMfEYZYYqKn4Afl=w600-h340-no)

 

아쉬운 점

 대규모 업데이트 이후 설정값이 다 초기화가 되었음.

 

p.s: 드디어 막힌 부분(마신으로 변한 데일)을 깸! 이히히히힣

한 10번 넘게 도전했네요.. 행동력 포션도 3개나 먹고 최고의 우군을 부르고 요리도 오지게 처먹고…ㅋㅋㅋㅋㅋㅋㅋㅋㅋ아무튼 깨고 나니까 고서도 합류되고 멜리오다스의 검도 찾고 좋아요.

아마 노가다작으로 키운 다이앤의 대진화가 없었다면 오늘도 완료가 힘들었을지도. 강화퀘스트로 받은 강화물약을 다이앤에게 전부 먹였더니 대진화가!? 29에서 50으로 한번에 점프 개꿀띠(대진화하면 경험치가 2배로 들어가요)

 

그리고 역시 멀린이 나올 차례가 맞았네요 멀린 떡밥 나옴ㅋㅋ

![update](https://lh3.googleusercontent.com/Ih8w5nrm8l3hQtkGmN7nYd5_F-RD4hkcsO-USvccvQE4CyHxdNP8ncKhZvVVzNWU_WS5o6az2H_lGFGKPTF1eGd511RoXsWjsaOKMKp_j4OFhtG1nfPyIahIetTXuk5FPuWrb5WxkJrBeuargzVHmh6cq7kDGzuiUVkT34YegKVdy805ca5xrzNmqrPJ2eEt2Klni7vo720ZAnte52Nip1risT3njknmOhrQFSK-VKGxQo1_c15qHaRdQCFxlAee-w3MypltmoAxnWehVHifYjsuA8dVM1WnShLmvVvq59J2JILMziqLrGYg57r8WA19cXVnuqvwMWhlTa-iMU2ocX806u-Kozm5gr_vpRN05PUh1zD8ssFfNU7_VBxukRdYzTFIgp_i1yTTqs2EiT8kartXFwbk3jlUucYA2PVsquD1MLvKLaDFhuxumEszhVdgBZn9euv_rAnpslXbwCMxQMMic2FBnnjC1pSzXMR-2gnqHfD3mq2715SEGJ07o_dOn2p4HFkHpgq40ynt6FoGtS5I5YPBsgkB_HNRqdwL5chQ5K0B8jkTk4mvp1uFFvZfCm3009IbCk_v_BnXSo8_AzqFAU1dYjJh1XNqhKrnlMSLllu04ekcIPuceSWKgGy_teq8twTaf_GuAhzCoQwU1wUivDzKccXIJUxs1PBCPls2MNo-MDqO_m4ECZj7yHRuhbtANRkVA526jEkdEgltdQ2T=w413-h870-no)